﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
