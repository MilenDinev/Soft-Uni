﻿using System;

namespace _06.Sneaking
{
    public class Startup
    {
        public static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            char[][] room = DrawField(n);

            Play(room);

        }


        public static char[][] DrawField(int n)
        {
            char[][] room = new char[n][];

            for (int row = 0; row < n; row++)
            {
                char[] input = Console.ReadLine().ToCharArray();
                room[row] = new char[input.Length];


                for (int col = 0; col < input.Length; col++)
                {
                    room[row][col] = input[col];
                }
            }

            return room;
        }


        public static int[] GetPLayerPosition(char[][] room)
        {
            int[] samPosition = new int[2];


            for (int row = 0; row < room.Length; row++)
            {
                for (int col = 0; col < room[row].Length; col++)
                {
                    if (room[row][col] == 'S')
                    {
                        samPosition[0] = row;
                        samPosition[1] = col;
                    }
                }
            }

            return samPosition;
        }

        public static int[] GetEnemyPosition(char[][] room, int[] playePosition)
        {
            int[] getEnemyPosition = new int[2];

            for (int j = 0; j < room[playePosition[0]].Length; j++)
            {
                if (room[playePosition[0]][j] != '.' && room[playePosition[0]][j] != 'S')
                {
                    getEnemyPosition[0] = playePosition[0];
                    getEnemyPosition[1] = j;
                }

            }

            return getEnemyPosition;
        }


        public static void Play(char[][] room)
        {
            int[] playePosition = GetPLayerPosition(room);
            char[] moves = Console.ReadLine().ToCharArray();


            for (int i = 0; i < moves.Length; i++)
            {
                PlayersMoves(room);



                int[] enemyPosition = GetEnemyPosition(room, playePosition);

                if (PlayerGotKilled(room, playePosition, enemyPosition))
                {
                    return;
                }


                room[playePosition[0]][playePosition[1]] = '.';

                switch (moves[i])
                {
                    case 'U':
                        playePosition[0]--;
                        break;
                    case 'D':
                        playePosition[0]++;
                        break;
                    case 'L':
                        playePosition[1]--;
                        break;
                    case 'R':
                        playePosition[1]++;
                        break;
                    default:
                        break;
                }


                room[playePosition[0]][playePosition[1]] = 'S';

                for (int j = 0; j < room[playePosition[0]].Length; j++)
                {
                    if (room[playePosition[0]][j] != '.' && room[playePosition[0]][j] != 'S')
                    {
                        enemyPosition[0] = playePosition[0];
                        enemyPosition[1] = j;
                    }
                }

                if (room[enemyPosition[0]][enemyPosition[1]] == 'N' && playePosition[0] == enemyPosition[0])
                {
                    EnemyGotKilled(room, enemyPosition);

                    return;
                }
            }
        }



        public static bool PlayerGotKilled(char[][] room, int[] playePosition, int[] enemyPosition )
        {
            bool playerGotKilled = false;

            if ((playePosition[1] < enemyPosition[1] && room[enemyPosition[0]][enemyPosition[1]] == 'd' && enemyPosition[0] == playePosition[0]) || enemyPosition[1] < playePosition[1] && room[enemyPosition[0]][enemyPosition[1]] == 'b' && enemyPosition[0] == playePosition[0])
            {
                room[playePosition[0]][playePosition[1]] = 'X';

                Console.WriteLine($"Sam died at {playePosition[0]}, {playePosition[1]}");
                for (int row = 0; row < room.Length; row++)
                {
                    for (int col = 0; col < room[row].Length; col++)
                    {
                        Console.Write(room[row][col]);
                    }
                    Console.WriteLine();
                }
                playerGotKilled = true;
            }

            return playerGotKilled;
        }

        public static void EnemyGotKilled(char[][] room, int[] enemyPosition)
        {
            room[enemyPosition[0]][enemyPosition[1]] = 'X';
            Console.WriteLine("Nikoladze killed!");
            for (int row = 0; row < room.Length; row++)
            {
                for (int col = 0; col < room[row].Length; col++)
                {
                    Console.Write(room[row][col]);
                }
                Console.WriteLine();
            }
            return;
        }

        public static void PlayersMoves(char[][] room)
        {
            for (int row = 0; row < room.Length; row++)
            {
                for (int col = 0; col < room[row].Length; col++)
                {
                    if (room[row][col] == 'b')
                    {
                        if (row >= 0 && row < room.Length && col + 1 >= 0 && col + 1 < room[row].Length)
                        {
                            room[row][col] = '.';
                            room[row][col + 1] = 'b';
                            col++;
                        }
                        else
                        {
                            room[row][col] = 'd';
                        }
                    }
                    else if (room[row][col] == 'd')
                    {
                        if (row >= 0 && row < room.Length && col - 1 >= 0 && col - 1 < room[row].Length)
                        {
                            room[row][col] = '.';
                            room[row][col - 1] = 'd';
                        }
                        else
                        {
                            room[row][col] = 'b';
                        }
                    }
                }
            }
        }
    }

}

