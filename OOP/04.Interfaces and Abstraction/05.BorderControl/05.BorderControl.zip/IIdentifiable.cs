﻿namespace _05.BorderControl
{
    public interface IIdentifiable
    {
        public string Id { get;}
    }
}
