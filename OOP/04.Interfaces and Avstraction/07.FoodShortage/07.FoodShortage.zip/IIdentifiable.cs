﻿namespace _07.FoodShortage
{
    public interface IIdentifiable
    {
        public string Id {get;}
        
    }
}
