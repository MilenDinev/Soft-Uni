﻿namespace _07.FoodShortage
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
