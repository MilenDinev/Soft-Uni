﻿using System.Collections.Generic;

namespace _04.Telephony
{
    public interface IBrowser
    {
        string Browsing(string url);
    }
}
