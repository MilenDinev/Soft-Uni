﻿using _01.Vehicles.Core;
using System;

namespace _01.Vehicles
{
   public class Startup
    {
        static void Main(string[] args)
        {
            Engine  engine = new Engine();
            engine.Run();
        }
    }
}
