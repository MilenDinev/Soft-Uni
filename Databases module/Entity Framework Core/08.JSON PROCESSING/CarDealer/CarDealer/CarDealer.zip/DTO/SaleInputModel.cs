﻿namespace CarDealer.DTO
{
    public class SaleInputModel
    {
        public int CarId { get; set; }
        public int CustomerId { get; set; }
        public int Discount { get; set; }
    }
}
