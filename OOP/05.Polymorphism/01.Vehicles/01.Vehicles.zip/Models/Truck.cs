﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace _01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double AdditionConsumption = 1.6;
        public Truck(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption + AdditionConsumption)
        {
        }

        public override void Refuel(double fuel)
        {

            fuel *= 0.95;

            base.Refuel(fuel);
        }
    }
}
