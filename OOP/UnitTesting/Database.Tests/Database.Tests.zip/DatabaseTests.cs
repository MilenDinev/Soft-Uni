using NUnit.Framework;
using System.Linq;
using System;


    public class DatabaseTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ConstructorShouldBeInitializedWith16Elements()
        {
            int[] numbers = Enumerable.Range(1, 16).ToArray();
            Database database = new Database(numbers);

            var expectedResult = 16;
            var actualResult = database.Count;

            Assert.AreEqual(actualResult, expectedResult);
        }

        [Test]
        public void ConstructorShouldBeThrowExceptionIfThereAreNot16Elements()
        {
            int[] numbers = Enumerable.Range(1, 10).ToArray();
            Database database = new Database(numbers);

            var expectedResult = 10;
            var actualResult = database.Count;

            Assert.AreEqual(actualResult, expectedResult);
        }

        [Test]  
        public void AddOperationShouldAddElementAtNextFreeCell()
        {
            //Arrange
            int[] numbers = Enumerable.Range(1, 10).ToArray();
            Database database = new Database(numbers);
            //Act
            database.Add(5);
            // Assert
            var allEments = database.Fetch();
            var expectedValue = 5;
            var actualResult = allEments[allEments.Length - 1];
            var expectedCount = 11;
            var actualCount = database.Count;
            Assert.AreEqual(expectedValue, actualResult);
            Assert.AreEqual(expectedCount, actualCount);
    }

        [Test]

        public void AddOperationShouldThrowExeptionIfElementAreAbove16()
        {
            //Arrange
            int[] numbers = Enumerable.Range(1, 16).ToArray();
            Database database = new Database(numbers);

            //Act Assert
            Assert.Throws<InvalidOperationException>(() => database.Add(10));
        }

        [Test]
        [TestCase(1,16,15,14)]

        public void RemoveOperationShouldSupportOnlyRemovingAnElementAtTheLastIndex(int startIndex, int count, int result, int index)
        {
            //Arrange
            int[] numbers = Enumerable.Range(startIndex, count).ToArray();
            Database database = new Database(numbers);
            //Act
            database.Remove();

            // Assert
            var expectedValue = result;
            var allEments = database.Fetch();
            var actualResult = allEments[index];

            var expectedCount =15;
            var actualCount = database.Count;

            Assert.AreEqual(expectedValue, actualResult);
            Assert.AreEqual(expectedCount, actualCount);
        }

        [Test]

        public void RemoveOperationShouldThrowExeptionIfDatabaseIsEmpty()
        {
            //Arrange
            Database database = new Database();

            // Act Assert
            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }


        [Test]

        public void FetchShouldReturnAllElements()
        {
            //Arrange
            int[] numbers = Enumerable.Range(1, 5).ToArray();
            Database database = new Database(numbers);

            // Act 
            var allItems = database.Fetch();
            //Assert

            int[] expectedValue = { 1, 2, 3, 4, 5 };

            CollectionAssert.AreEqual(expectedValue, allItems);

        }
    }
