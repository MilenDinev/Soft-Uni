﻿using _01.Vehicles.Core;
using System;

namespace _01.Vehicles
{
   public class Startup
    {
        static void Main()
        {
            Engine  engine = new Engine();
            engine.Run();
        }
    }
}
