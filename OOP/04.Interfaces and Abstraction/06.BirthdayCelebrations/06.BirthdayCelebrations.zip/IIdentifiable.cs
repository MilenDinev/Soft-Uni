﻿namespace _06.BirthdayCelebrations
{
    public interface IIdentifiable
    {
        public string Id {get;}
        
    }
}
