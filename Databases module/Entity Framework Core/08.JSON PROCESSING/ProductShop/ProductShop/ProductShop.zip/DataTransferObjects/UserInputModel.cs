﻿namespace ProductShop.DataTransferObjects
{
    public class UserInputModel
    {
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public int? Age { get; set; }
    }
}
