﻿namespace ProductShop
{
    using AutoMapper;
    using CarDealer.XMLHelper;
    using ProductShop.Data;
    using ProductShop.Dtos.Import;
    using ProductShop.Models;
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class StartUp
    {
        static IMapper mapper;

        public static void Main(string[] args)
        {
            var context = new ProductShopContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var usersXML = File.ReadAllText("../../../Datasets/users.xml");
            Console.WriteLine(ImportUsers(context, usersXML));

        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            InitializeAutoMapper();
            var usersDto = XmlConverter.Deserializer<UserImportModel>(inputXml, "Users");
            var users = mapper.Map<IEnumerable<User>>(usersDto);
            context.Users.AddRange(users);
            var result = context.SaveChanges();

            return $"Successfully imported {result}";
        }



        private static void InitializeAutoMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<ProductShopProfile>();
            });

            mapper = config.CreateMapper();
        }
    }


}