﻿namespace ProductShop.Dtos.Import
{
    using System.Xml.Serialization;

    public class ProductImportModel
    {
    }
}
