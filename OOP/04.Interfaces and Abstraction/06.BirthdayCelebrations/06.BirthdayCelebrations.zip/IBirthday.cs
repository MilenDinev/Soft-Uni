﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.BirthdayCelebrations
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
