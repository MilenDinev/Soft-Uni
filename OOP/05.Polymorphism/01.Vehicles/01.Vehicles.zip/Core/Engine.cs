﻿namespace _01.Vehicles.Core
{
    using System;
    using System.Security;
    using Models;
    public class Engine
    {
        public void Run()
        {
            string[] carInfo = Console.ReadLine().Split();
            string[] truckInfo = Console.ReadLine().Split();

            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumtion = double.Parse(carInfo[2]);

            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumtion = double.Parse(truckInfo[2]);

            Vehicle car = new Car(carFuelQuantity, carFuelConsumtion);
            Vehicle truck = new Truck(truckFuelQuantity, truckFuelConsumtion);

            int rotations = int.Parse(Console.ReadLine());

            for (int i = 0; i < rotations; i++)
            {
                string[] commandArgs = Console.ReadLine().Split();

                string command = commandArgs[0];
                string vehicleType = commandArgs[1];
                string value = commandArgs[2];

                if (command == "Drive")
                {
                    double distance = double.Parse(value);

                    if (vehicleType == "Car")
                    {
                        Console.WriteLine(car.Drive(distance));
                    }
                    else if (vehicleType == "Truck")
                    {
                        Console.WriteLine(truck.Drive(distance));
                    }
                }
                else if (command == "Refuel")
                {
                    double fuel = double.Parse(value);
                    if (vehicleType == "Car")
                    {
                        car.Refuel(fuel);
                    }
                    else if (vehicleType == "Truck")
                    {
                        truck.Refuel(fuel);
                    }
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);

        }
    }
}
